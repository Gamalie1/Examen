/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.udb.guia9Controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sv.edu.udb.guia9.PersonaBean;

/**
 *
 * @author labso08
 */
public class Inicio extends HttpServlet {

   

  
    protected void doPOST(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out= response.getWriter();
       PersonaBean bean=new PersonaBean();
       
       bean.setNombre(request.getParameter("nombre1"));
       bean.setEdad(Integer.parseInt(request.getParameter("edad1")));
       out.print("HOLA"+bean.getNombre()+"Tienes la edad de"+bean.getEdad());
    }

  
}
